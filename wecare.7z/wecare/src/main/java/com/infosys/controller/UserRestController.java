package com.infosys.controller;

public class UserRestController {

}
