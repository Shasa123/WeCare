package com.infosys.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infosys.entity.BookEntity;

@Repository
public interface BookRepository extends JpaRepository<BookEntity, String> {

	Optional<BookEntity> findByUserId(String userId);

	List<BookEntity> findBookingByUserId(String userID, LocalDate today);

	List<BookEntity> findBookingByCoachID(String coachId, LocalDate today);

	BookEntity findAllBookings(String userId, LocalDate appointmentDate, String slot);
}
