package com.infosys.entity;

import javax.persistence.Entity;

@Entity
public class CoachEntity {

}
