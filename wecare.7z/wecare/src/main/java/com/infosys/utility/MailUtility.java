package com.infosys.utility;

public class MailUtility {

}
